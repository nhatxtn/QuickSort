package QuickSort;

import QuickSort.Node;
import QuickSort.Array;

public class LLQuickSort {
    Node head,tail;
    public LLQuickSort(int[] a){
        head = tail = null;
        for (int i : a) {
            insertAfter(new Node(i), tail);
        }
    }
    void insertAfter(Node t, Node pred){
        if(pred == null){
            t.next = head;
            head = t;
        } else{
            t.next = pred.next;
            pred.next = t;
        }
        if(pred == tail) tail =null;

    }
    void display(Node t){
        if (t == null) return;
        else if(t.next!=null) {
            System.out.print(t.value + "->");
        }
        else System.out.println(t.value);
        display(t.next);
    }
    boolean checkIncreased(Node p){
        if (p == null || p.next == null){
            return true;
        } else {
            return (p.value <= p.next.value && checkIncreased(p.next));
        }
    }
    Node paritionLast(Node start, Node end)
    {

        Node pivot_prev = start;       //keep the position of the pivot
        Node curr = start;             //keep the position of bigger node
        int pivot = end.value;

        while (start != end.next) {
            if (start.value < pivot) {
                pivot_prev = curr;
                swap(curr,start);
                curr = curr.next;
            }
            start = start.next;
        }

        swap(curr,end);

        return pivot_prev;
    }
    void quickSortLast(Node start, Node end)
    {
        if (start == end )
            return;
        Node pivot_prev = paritionLast(start, end);
        quickSortLast(start, pivot_prev);
        quickSortLast(pivot_prev.next, end);

    }
    Node partition(Node start, Node end){

        int pivot = start.value;
        Node pre = start;
        Node curr = start;
        Node q = start.next;
        while (q != end.next){
            if (q.value < pivot){
                pre = curr;
                curr = curr.next;
                swap(curr,q);
            }
            q=q.next;
        }
        swap(curr,start);
        return curr;
    }
    void quicksorttwo(Node start, Node end){
        if(start != end){
            Node in = partition(start,end);
            quicksorttwo(start,in);
            quicksorttwo(in.next, end);
        }
    }

    void swap(Node a, Node b){
        int temp = a.value;
        a.value = b.value;
        b.value = temp;
    }
//    Node partitionFirst(Node start, Node end){
//        Node prePivot = start;
//        Node curr = start;
//        int pivot = start.value;
//        while (start != end.next){
//            if(start.value < pivot){
//                prePivot = curr;
//                swap(curr,start);
//                curr = curr.next;
//            }
//            start = start.next;
//        }
//
//        return prePivot;
//    }
//    void quickSortFirst(Node start, Node end){
//        if (start == end )
//            return;
//        Node pivot_prev = partitionFirst(start, end);
//        quickSortFirst(start, pivot_prev);
//        quickSortFirst(pivot_prev.next, end);
//    }


    public static void main(String[] args) {
        Array a = new Array(1000, 5, 6, 10, 99);

        LLQuickSort sort = new LLQuickSort(a.getA());
        sort.display(sort.head);
        Node n = sort.head;
        while (n.next != null)
            n = n.next;
        sort.quicksorttwo(sort.head,n);
        sort.display(sort.head);
        if(sort.checkIncreased(sort.head))
            System.out.println("is increased");
    }
}
