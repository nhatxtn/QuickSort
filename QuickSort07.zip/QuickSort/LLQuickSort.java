package QuickSort;

import QuickSort.Node;
import QuickSort.Array;

public class LLQuickSort {
    Node head,tail;
    public LLQuickSort(int[] a){
        head = tail = null;
        for (int i : a) {
            insertAfter(new Node(i), tail);
        }
    }
    void insertAfter(Node t, Node pred){
        if(pred == null){
            t.next = head;
            head = t;
        } else{
            t.next = pred.next;
            pred.next = t;
        }
        if(pred == tail) tail =null;

    }
    void display(Node t){
        if (t == null) return;
        else if(t.next!=null) {
            System.out.print(t.value + "->");
        }
        else System.out.println(t.value);
        display(t.next);
    }
    boolean checkIncreased(Node p){
        if (p == null || p.next == null){
            return true;
        } else {
            return (p.value < p.next.value && checkIncreased(p.next));
        }
    }
    Node paritionLast(Node start, Node end)
    {
        if (start == null || end == null)
            return start;
        Node pivot_prev = start;
        Node curr = start;
        int pivot = end.value;

        while (start != end) {
            if (start.value < pivot) {
                pivot_prev = curr;
                swap(curr,start);
                curr = curr.next;
            }
            start = start.next;
        }

        swap(curr,end);

        return pivot_prev;
    }
    void sort(Node start, Node end)
    {
        if (start == end )
            return;
        Node pivot_prev = paritionLast(start, end);
        sort(start, pivot_prev);
        sort(pivot_prev.next, end);

    }
    Node partitionFirst(Node start, Node end){
        if (start == null || end == null)
            return start;
        Node prePivot = start;
        Node curr = start;
        int pivot = start.value;
        while (start != end.next){
            if(start.value < pivot){
                prePivot = curr;
                swap(curr,start);
                curr = curr.next;
            }
            start = start.next;
        }

        return prePivot;
    }
    void swap(Node a, Node b){
        int temp = a.value;
        a.value = b.value;
        b.value = temp;
    }
    void quickSort(Node start, Node end){
        if (start == end )
            return;
        Node pivot_prev = partitionFirst(start, end);
        quickSort(start, pivot_prev);
        quickSort(pivot_prev.next, end);
    }


    public static void main(String[] args) {
        Array a = new Array(870, 5, 6, 10, 99);
        LLQuickSort sort = new LLQuickSort(a.getA());
        sort.display(sort.head);
        Node n = sort.head;
        while (n.next != null)
            n = n.next;
        sort.sort(sort.head,n);
        sort.display(sort.head);
        if(sort.checkIncreased(sort.head))
            System.out.println("is increased");
    }
}
