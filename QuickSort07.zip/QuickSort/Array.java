package QuickSort;

import java.util.Arrays;
import java.util.Random;

public class Array {

    int[] a;
    int n;
    public Array(int seed, int minSize, int maxSize, int minVal, int maxVal) {
        Random rnd;
        if (seed < 0) rnd = new Random();
        else rnd = new Random(seed);
        n = minSize + rnd.nextInt(maxSize-minSize+1);
        a = new int[n + 1];
        for(int i = 0; i < n + 1; i++) {
            a[i] = minVal + rnd.nextInt(maxVal-minVal+1);
        }
    }


    public int[] getA() {
        return a;
    }


}

