package QuickSort;

import java.util.Arrays;

public class QuickSort {

    void partitionTwo(int[] arr, int low , int high){
        if(low>=high) return;
        int pivot = arr[(low+high)/2];
        int left = low;
        int right = high;
        do {
           while ( arr[left] < pivot) left++;
            while (arr[right] > pivot) right--;
            if(left<=right) {
            swap(arr, left,right);
            left++;
            right--;}
        } while (left<=right);
        partitionTwo(arr,low,right);
        partitionTwo(arr,left,high);
    }
    void swap(int[]arr, int i , int j){
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    int partition (int arr[], int low, int high)
    {

        int pivot = arr[high];    // pivot
        int left = low;
        int right = high - 1;
        while(true){
            while(left <= right && arr[left] < pivot) left++; // Tìm phần tử >= arr[pivot]
            while(right >= left && arr[right] > pivot) right--; // Tìm phần tử <= arr[pivot]
            if (left >= right) break; // Đã duyệt xong thì thoát vòng lặp
            swap(arr, left,right);
            // Nếu chưa xong, đổi chỗ.
            left++; // Vì left hiện tại đã xét, nên cần tăng
            right--; // Vì right hiện tại đã xét, nên cần giảm
        }
        swap(arr,left,high);
        return left; // Trả về chỉ số sẽ dùng để chia đổi mảng
    }
    // arr[] --> Mảng cần được sắp xếp,
    // low --> chỉ mục bắt đầu,
    // high --> chỉ mục kết thúc
    void quickSort(int arr[], int low, int high)
    {
        if (low < high)
        {
        /* pi là chỉ số nơi phần tử này đã đứng đúng vị trí
         và là phần tử chia mảng làm 2 mảng con trái & phải */
            int pi = partition(arr, low, high);

            // Gọi đệ quy sắp xếp 2 mảng con trái và phải
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }
     int subPartition(int[] arr , int low , int high){
        int left = low + 1;
        int right = high;
        int pivot = arr[low];
        while (true){
            while (left <= right && arr[left] < pivot) left++;
            while (right >= left && arr[right] > pivot) right--;
            if(left >= right) break;
            swap(arr,left,right);
            left++;
            right--;
        }
        swap(arr,right,low);
        return right;
    }
     void subQuickSort(int[] arr, int low, int high){
        if (low < high){
            int in = subPartition(arr, low, high);
            subQuickSort(arr,low ,in -1 );
            subQuickSort(arr ,in+1,high);
        }
    }
    // In các phần tử của mảng
    void printArray(int arr[]) {


        System.out.println(Arrays.toString(arr));
    }

    public static void main(String[] args) {
        int arr[] = {5, 12, 22, 4, 2, 8,4, 8, 9 };
        int n = arr.length;
        System.out.println(Arrays.toString(arr));
        QuickSort ob = new QuickSort();
        ob.quickSort(arr, 0, n - 1);
        ob.printArray(arr);
    }
}