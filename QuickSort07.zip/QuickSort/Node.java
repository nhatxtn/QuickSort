package QuickSort;

public class Node {
    int value;
    Node next;
    public Node(int x){
        value = x;
        next = null;
    }
}
